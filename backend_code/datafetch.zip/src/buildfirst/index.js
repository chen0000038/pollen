const mysql = require('mysql2/promise');
const pool = mysql.createPool({
  host: process.env.MYSQL_HOST || 'database-build.ch4e46mkctb1.ap-southeast-2.rds.amazonaws.com',
  port: process.env.MYSQL_PORT || 3306,
  user: process.env.MYSQL_USER || 'admin',
  password: process.env.MYSQL_PASSWORD || 'Shy20010101',
  database: process.env.MYSQL_DATABASE || 'pollen_db',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

exports.handler = async (event) => {
  console.log('Using DB:', process.env.MYSQL_DATABASE);
  if (event.httpMethod !== 'GET') {
    return {
      statusCode: 405,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: 'Method Not Allowed' })
    };
  }
  
  try {
    const connection = await pool.getConnection();
    const [forecastResults] = await connection.query('SELECT * FROM Melbourne_Pollen_Forecast_2025');
    const [trendResults] = await connection.query('SELECT * FROM Monthly_Pollen_Trend_Melbourne');
    const [plantResults] = await connection.query('SELECT * FROM Plant_Pollen_Contributors');
    const [seasonalResults] = await connection.query('SELECT * FROM Seasonal_Pollen_Trends_Melbourne');
    const [descriptionResults] = await connection.query('SELECT * FROM plant_description_list');
    connection.release();
    
    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*' 
      },
      body: JSON.stringify({ forecastResults, trendResults, plantResults, seasonalResults, descriptionResults })
    };
  } catch (err) {
    console.error('Error fetching data:', err);
    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: 'Error fetching data from database.' })
    };
  }
};
